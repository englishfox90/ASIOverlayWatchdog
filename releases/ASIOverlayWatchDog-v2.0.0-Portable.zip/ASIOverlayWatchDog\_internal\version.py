"""
Application version
Single source of truth for version number across all build systems
"""

__version__ = "2.0.0"
